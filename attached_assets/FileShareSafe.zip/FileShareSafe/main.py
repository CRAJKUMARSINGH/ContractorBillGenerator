import os
import logging
from flask import Flask, render_template, request, flash, redirect, url_for, jsonify, session
from werkzeug.utils import secure_filename
import pandas as pd
import numpy as np
import traceback
from datetime import datetime

from utils.excel_processor import process_excel_file
from models import db, Bill, BillItem, BillDeviation

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key_for_development")

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
if not app.config["SQLALCHEMY_DATABASE_URI"]:
    logger.error("DATABASE_URL environment variable not set!")
    # Provide a fallback for local development
    app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///bills.sqlite"

app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Configure upload settings
app.config['UPLOAD_FOLDER'] = '/tmp'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # Limit file size to 16MB

# Initialize the database with the app
db.init_app(app)

# Create database tables if they don't exist
with app.app_context():
    db.create_all()

# Configure allowed extensions
ALLOWED_EXTENSIONS = {'xlsx', 'xls'}

# Helper function to check file extension
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    # Get the most recent bills for display
    try:
        bills = Bill.query.order_by(Bill.created_at.desc()).limit(5).all()
        return render_template('index.html', recent_bills=bills)
    except Exception as e:
        logger.error(f"Error in index route: {str(e)}")
        return render_template('index.html', recent_bills=[])

@app.route('/test')
def test():
    return "Server is working! Test route is accessible."

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'GET':
        return redirect(url_for('index'))
        
    try:
        # Check if the post request has the file part
        if 'excel_file' not in request.files:
            flash('No file part', 'danger')
            return redirect(url_for('index'))
        
        file = request.files['excel_file']
        
        # If user does not select file, browser may submit an empty file without a filename
        if file.filename == '':
            flash('No selected file', 'danger')
            return redirect(url_for('index'))
        
        # Get additional form data
        last_paid_amount = request.form.get('last_paid_amount', 0)
        try:
            last_paid_amount = float(last_paid_amount)
        except ValueError:
            flash('Last paid amount must be a number', 'danger')
            return redirect(url_for('index'))
        
        is_final_bill = 'is_final_bill' in request.form
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            # Process the Excel file
            bill_data = process_excel_file(filepath, last_paid_amount, is_final_bill)
            
            # Store data in session for the result page
            session['bill_data'] = bill_data
            
            # Save to database
            try:
                # Create a new bill from the processed data
                new_bill = Bill.from_bill_data(bill_data)
                
                # Add and commit to database
                db.session.add(new_bill)
                db.session.commit()
                
                # Store the bill ID in session
                session['bill_id'] = new_bill.id
                
                logger.info(f"Bill saved to database with ID: {new_bill.id}")
            except Exception as db_error:
                logger.error(f"Error saving bill to database: {str(db_error)}")
                logger.error(traceback.format_exc())
                # Continue even if database save fails
            
            return redirect(url_for('result'))
        else:
            flash('Invalid file type. Only Excel files (.xlsx, .xls) are allowed.', 'danger')
            return redirect(url_for('index'))
    
    except Exception as e:
        logger.error(f"Error processing upload: {str(e)}")
        logger.error(traceback.format_exc())
        flash(f'Error processing file: {str(e)}', 'danger')
        return redirect(url_for('index'))

@app.route('/result')
def result():
    # Try to get bill from database first
    bill_id = session.get('bill_id')
    if bill_id:
        bill = Bill.query.get(bill_id)
        if bill:
            bill_data = bill.to_dict()
            return render_template('result.html', bill_data=bill_data)
    
    # Fallback to session data if database retrieval fails
    bill_data = session.get('bill_data')
    if not bill_data:
        flash('No bill data found. Please upload a file first.', 'warning')
        return redirect(url_for('index'))
    
    return render_template('result.html', bill_data=bill_data)

@app.route('/bill/<int:bill_id>')
def view_bill(bill_id):
    bill = Bill.query.get_or_404(bill_id)
    return render_template('result.html', bill_data=bill.to_dict())

@app.route('/bills')
def bill_history():
    bills = Bill.query.order_by(Bill.created_at.desc()).all()
    return render_template('bills.html', bills=bills)

@app.route('/check_file', methods=['POST'])
def check_file():
    try:
        if 'excel_file' not in request.files:
            return jsonify({'valid': False, 'message': 'No file selected'})
        
        file = request.files['excel_file']
        
        if file.filename == '':
            return jsonify({'valid': False, 'message': 'No file selected'})
        
        if not allowed_file(file.filename):
            return jsonify({'valid': False, 'message': 'Invalid file type. Only Excel files (.xlsx, .xls) are allowed.'})
        
        # Save the file temporarily
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Try to read the file with pandas to validate it
        try:
            # Try to read with different engines to maximize compatibility
            try:
                df = pd.read_excel(filepath)
            except Exception as excel_error:
                try:
                    # Fall back to openpyxl engine
                    logger.warning(f"Initial Excel read failed, trying openpyxl engine: {str(excel_error)}")
                    df = pd.read_excel(filepath, engine='openpyxl')
                except Exception as openpyxl_error:
                    logger.error(f"Failed to read Excel with openpyxl: {str(openpyxl_error)}")
                    raise ValueError(f"Cannot read this Excel file. Please check the file format. Error: {str(excel_error)}")
            
            # Check if the dataframe has any data
            if df.empty:
                return jsonify({'valid': False, 'message': 'The Excel file is empty. Please upload a file with data.'})
            
            # Log details for debugging
            logger.debug(f"Excel file columns: {list(df.columns)}")
            logger.debug(f"Excel file shape: {df.shape}")
            
            # Convert column names to lowercase for case-insensitive comparison and remove whitespace
            df.columns = [str(col).lower().strip() for col in df.columns]
            
            # Look for columns with no names (often happen with badly formatted Excel files)
            unnamed_cols = [col for col in df.columns if 'unnamed' in str(col).lower()]
            if unnamed_cols and len(unnamed_cols) > len(df.columns) / 2:
                # If more than half the columns are unnamed, this might be a badly structured file
                logger.warning(f"File has many unnamed columns: {unnamed_cols}")
                # But we'll still try to process it
            
            # Get numeric columns as potential valid data sources
            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
            text_cols = df.select_dtypes(include=['object', 'string']).columns.tolist()
            
            logger.debug(f"Numeric columns: {numeric_cols}")
            logger.debug(f"Text columns: {text_cols}")
            
            # Check for essential columns with expanded search patterns
            item_column_found = any(any(item_term in col for item_term in ['item', 'name', 'description', 'service', 'product', 'unnamed']) 
                                   for col in df.columns)
            
            current_column_found = any(any(current_term in col for current_term in ['current', 'curr', 'present', 'reading', 'value', 'amount'])
                                      for col in df.columns) or len(numeric_cols) >= 1
            
            # Build detailed validation messages
            feedback = []
            if not item_column_found and not text_cols:
                feedback.append("No text columns found that could represent items")
            
            if not current_column_found and not numeric_cols:
                feedback.append("No numeric columns found for readings or values")
            
            # Comprehensive validation check
            if (not item_column_found or not current_column_found) and (not text_cols or not numeric_cols):
                return jsonify({
                    'valid': False, 
                    'message': f'This file may not contain the required data structure. {" ".join(feedback)}. ' +
                              'The file should have at least one column for item names and one numeric column for readings.'
                })
            
            # Check data quality
            if len(df) < 1:
                return jsonify({'valid': False, 'message': 'The file contains column headers but no data rows.'})
            
            # Generate appropriate success message based on what we found
            if item_column_found and current_column_found:
                return jsonify({'valid': True, 'message': "File is valid and contains the required columns."})
            elif text_cols and numeric_cols:
                return jsonify({
                    'valid': True, 
                    'message': "File structure looks good. The application will automatically identify the appropriate columns."
                })
            else:
                # If we have at least some usable data, we'll try to work with it
                return jsonify({
                    'valid': True, 
                    'message': "File doesn't have standard column names, but the application will attempt to process it."
                })
            
        except Exception as e:
            logger.error(f"Error validating Excel file: {str(e)}")
            logger.error(traceback.format_exc())
            return jsonify({
                'valid': False, 
                'message': f'Error reading Excel file: {str(e)}. Please ensure the file is a valid Excel spreadsheet.'
            })
            
    except Exception as e:
        logger.error(f"Error in check_file: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'valid': False, 'message': f'Error processing file: {str(e)}'})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)