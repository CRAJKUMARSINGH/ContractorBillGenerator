import pandas as pd
import numpy as np
import os
import logging
from datetime import datetime
from typing import Dict, Any, List, Tuple, Optional

logger = logging.getLogger(__name__)

def number_to_words(amount):
    """
    Convert a numerical amount to words (e.g., 123 -> 'One Hundred Twenty-Three').
    Args:
        amount: Integer or float amount to convert.
    Returns:
        String representation of the amount in words.
    """
    try:
        # We'll use a simpler approach since num2words might not be available
        amount = int(round(float(amount)))
        return str(amount)
    except (ValueError, TypeError):
        return str(amount)

def is_extra_item_sheet_empty(ws_extra):
    """
    Check if the Extra Items sheet DataFrame is empty or contains only null values.
    Args:
        ws_extra: pandas DataFrame representing the Extra Items sheet.
    Returns:
        Boolean indicating if the sheet is empty.
    """
    if not isinstance(ws_extra, pd.DataFrame):
        return True
    return ws_extra.empty or ws_extra.dropna(how='all').empty

def process_excel_bill(filepath: str, user_inputs: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Process Excel bill file to generate bill data
    
    Args:
        filepath: Path to the uploaded Excel file
        user_inputs: Dictionary of user inputs (agreement number, work details, etc.)
        
    Returns:
        Dictionary containing processed bill data with all bill sections
    """
    if user_inputs is None:
        user_inputs = {}
    
    # Default values for user inputs
    premium_percent = user_inputs.get('premium_percent', 10.0)
    premium_type = user_inputs.get('premium_type', 'above')
    amount_paid_last_bill = user_inputs.get('last_paid_amount', 0.0)
    is_first_bill = user_inputs.get('is_first_bill', True)
    is_final_bill = user_inputs.get('is_final_bill', False)
    
    try:
        # Try to read with different engines to maximize compatibility
        try:
            xl = pd.ExcelFile(filepath)
            sheet_names = xl.sheet_names
            
            # Load work order sheet
            ws_wo = pd.read_excel(filepath, sheet_name=sheet_names[0])
            
            # Load bill quantity sheet (same as work order if only one sheet)
            ws_bq = ws_wo if len(sheet_names) == 1 else pd.read_excel(filepath, sheet_name=sheet_names[1])
            
            # Load extra items sheet if available
            ws_extra = pd.DataFrame() if len(sheet_names) <= 2 else pd.read_excel(filepath, sheet_name=sheet_names[2])
            
        except Exception as excel_error:
            logger.error(f"Error reading Excel file: {str(excel_error)}")
            raise ValueError(f"Cannot process this Excel file. Error: {str(excel_error)}")
        
        # Check if dataframes have data
        if ws_wo.empty:
            raise ValueError("The Excel file first sheet is empty")
            
        # Process the bill
        first_page_data, certificate_ii_data, certificate_iii_data, deviation_data, extra_items_data, note_sheet_data = process_bill(
            ws_wo, ws_bq, ws_extra, premium_percent, premium_type, amount_paid_last_bill, is_first_bill, is_final_bill, user_inputs
        )
        
        # Compile all data into one structure
        bill_data = {
            "first_page": first_page_data,
            "certificate_ii": certificate_ii_data,
            "certificate_iii": certificate_iii_data,
            "deviation": deviation_data,
            "extra_items": extra_items_data,
            "note_sheet": note_sheet_data,
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_amount": first_page_data["totals"]["grand_total"],
            "final_amount": first_page_data["totals"]["payable"],
            "is_final_bill": is_final_bill
        }
        
        return bill_data
        
    except Exception as e:
        logger.error(f"Error processing Excel bill: {str(e)}")
        raise

def process_bill(ws_wo, ws_bq, ws_extra, premium_percent, premium_type, amount_paid_last_bill, is_first_bill, is_final_bill, user_inputs):
    """
    Process the bill data from Excel sheets
    
    Args:
        ws_wo: Work order DataFrame
        ws_bq: Bill quantity DataFrame
        ws_extra: Extra items DataFrame
        premium_percent: Premium percentage
        premium_type: Premium type ('above' or 'below')
        amount_paid_last_bill: Amount paid in last bill
        is_first_bill: Whether this is the first bill
        is_final_bill: Whether this is the final bill
        user_inputs: Dictionary of user inputs
        
    Returns:
        Tuple containing all processed data sections
    """
    logger.debug("Starting process_bill")
    
    # Initialize data structures
    first_page_data = {"header": {}, "items": [], "totals": {}}
    certificate_ii_data = {"payable_amount": 0, "amount_words": "", "summary": {}}
    certificate_iii_data = {"payable_amount": 0, "amount_words": "", "summary": {}, "certification": "Certified that the work has been completed as per specifications."}
    deviation_data = {"items": [], "summary": {}} if is_final_bill else None
    extra_items_data = {"items": [], "totals": {"payable": 0}}
    note_sheet_data = {
        "notes": [],
        "header": {},
        "totals": {},
        "work_order_amount": user_inputs.get("work_order_amount", 854678.0)
    }

    # Header data from user inputs
    first_page_data["header"] = {
        "agreement_no": user_inputs.get("agreement_no", "48/2024-25"),
        "name_of_work": user_inputs.get("name_of_work", "Electric Repair and MTC work at Govt. Ambedkar hostel Ambamata, Govardhanvilas, Udaipur"),
        "name_of_firm": user_inputs.get("name_of_firm", "M/s Seema Electrical Udaipur"),
        "date_commencement": user_inputs.get("date_commencement", "18/01/2025"),
        "date_completion": user_inputs.get("date_completion", "17/04/2025"),
        "actual_completion": user_inputs.get("actual_completion", "01/03/2025"),
        "serial_no_bill": user_inputs.get("serial_no_bill", "First & Final Bill" if is_final_bill else "First Bill" if is_first_bill else "Running Bill"),
        "work_order_ref": user_inputs.get("work_order_ref", "1179 dated 09-01-2025"),
        "measurement_date": user_inputs.get("measurement_date", "03/03/2025"),
        "work_order_amount": user_inputs.get("work_order_amount", 854678.0)
    }
    note_sheet_data["header"] = first_page_data["header"].copy()

    # Log sheet shapes and sample data for debugging
    logger.debug(f"Work Order shape: {ws_wo.shape}")
    logger.debug(f"Bill Quantity shape: {ws_bq.shape}")
    if not ws_extra.empty:
        logger.debug(f"Extra Items shape: {ws_extra.shape}")

    # Validate sheets
    if ws_wo.empty or ws_bq.empty:
        raise ValueError("Work Order or Bill Quantity sheet is empty")

    # Determine where data starts - adapt to the format of the input file
    data_start_row = 0
    for i in range(min(30, ws_wo.shape[0])):
        if isinstance(ws_wo.iloc[i, 0], str) and any(keyword in str(ws_wo.iloc[i, 0]).lower() for keyword in ['item', 'description', 'work']):
            data_start_row = i + 1
            break
    
    # If we couldn't find a header row, assume data starts at row 0
    if data_start_row == 0:
        data_start_row = 0
        
    logger.debug(f"Data appears to start at row {data_start_row}")

    # Process Work Order items
    last_row_wo = ws_wo.shape[0]
    for i in range(data_start_row, last_row_wo):
        # Skip rows with no data
        if pd.isna(ws_wo.iloc[i, 0]) and pd.isna(ws_wo.iloc[i, 1]) and pd.isna(ws_wo.iloc[i, 2]):
            continue

        # Extract data ensuring proper type conversion
        qty_raw = ws_bq.iloc[i, 2] if i < ws_bq.shape[0] and pd.notnull(ws_bq.iloc[i, 2]) else None
        rate_raw = ws_wo.iloc[i, 3] if pd.notnull(ws_wo.iloc[i, 3]) else None

        qty = 0
        if isinstance(qty_raw, (int, float)):
            qty = float(qty_raw)
        elif isinstance(qty_raw, str):
            cleaned_qty = qty_raw.strip().replace(',', '').replace(' ', '')
            try:
                qty = float(cleaned_qty)
            except ValueError:
                logger.debug(f"Skipping invalid quantity at Bill Quantity row {i+1}: '{qty_raw}'")
                continue

        rate = 0
        if isinstance(rate_raw, (int, float)):
            rate = float(rate_raw)
        elif isinstance(rate_raw, str):
            cleaned_rate = rate_raw.strip().replace(',', '').replace(' ', '')
            try:
                rate = float(cleaned_rate)
            except ValueError:
                logger.debug(f"Skipping invalid rate at Work Order row {i+1}: '{rate_raw}'")
                continue

        # Create item dictionary
        item = {
            "serial_no": str(i - data_start_row + 1),
            "description": str(ws_wo.iloc[i, 0]) if pd.notnull(ws_wo.iloc[i, 0]) else "",
            "unit": str(ws_wo.iloc[i, 1]) if pd.notnull(ws_wo.iloc[i, 1]) else "",
            "quantity": qty,
            "rate": rate,
            "amount": round(qty * rate) if qty and rate else 0,
            "bsr": str(ws_wo.iloc[i, 5]) if i < ws_wo.shape[1] and pd.notnull(ws_wo.iloc[i, 5]) else "",
            "remark": str(ws_wo.iloc[i, 6]) if i < ws_wo.shape[1] and pd.notnull(ws_wo.iloc[i, 6]) else "",
            "is_divider": False
        }
        first_page_data["items"].append(item)

    # Extra Items processing (optional)
    if not ws_extra.empty and ws_extra.shape[0] >= 1:
        first_page_data["items"].append({
            "description": "Extra Items (With Premium)",
            "bold": True,
            "underline": True,
            "amount": 0,
            "quantity": 0,
            "rate": 0,
            "serial_no": "",
            "unit": "",
            "bsr": "",
            "remark": "",
            "is_divider": True
        })

        # Find start of data in extra items
        extra_start_row = 0
        for i in range(min(10, ws_extra.shape[0])):
            if isinstance(ws_extra.iloc[i, 0], str) and any(keyword in str(ws_extra.iloc[i, 0]).lower() for keyword in ['item', 'description', 'sl', 'serial']):
                extra_start_row = i + 1
                break
        
        # Process extra items
        last_row_extra = ws_extra.shape[0]
        for j in range(extra_start_row, last_row_extra):
            # Skip empty rows
            if pd.isna(ws_extra.iloc[j, 0]) and pd.isna(ws_extra.iloc[j, 1]) and pd.isna(ws_extra.iloc[j, 2]):
                continue
                
            qty_raw = ws_extra.iloc[j, 3] if j < ws_extra.shape[1] and pd.notnull(ws_extra.iloc[j, 3]) else None
            rate_raw = ws_extra.iloc[j, 4] if j < ws_extra.shape[1] and pd.notnull(ws_extra.iloc[j, 4]) else None
            amount_raw = ws_extra.iloc[j, 5] if j < ws_extra.shape[1] and pd.notnull(ws_extra.iloc[j, 5]) else None

            qty = 0
            if isinstance(qty_raw, (int, float)):
                qty = float(qty_raw)
            elif isinstance(qty_raw, str):
                cleaned_qty = qty_raw.strip().replace(',', '').replace(' ', '')
                try:
                    qty = float(cleaned_qty)
                except ValueError:
                    logger.debug(f"Skipping invalid quantity at Extra Items row {j+1}: '{qty_raw}'")
                    continue

            rate = 0
            if isinstance(rate_raw, (int, float)):
                rate = float(rate_raw)
            elif isinstance(rate_raw, str):
                cleaned_rate = rate_raw.strip().replace(',', '').replace(' ', '')
                try:
                    rate = float(cleaned_rate)
                except ValueError:
                    logger.debug(f"Skipping invalid rate at Extra Items row {j+1}: '{rate_raw}'")
                    continue

            amount = 0
            if isinstance(amount_raw, (int, float)):
                amount = float(amount_raw)
            elif isinstance(amount_raw, str):
                cleaned_amount = amount_raw.strip().replace(',', '').replace(' ', '')
                try:
                    amount = float(cleaned_amount)
                except ValueError:
                    logger.debug(f"Skipping invalid amount at Extra Items row {j+1}: '{amount_raw}'")
                    continue

            item = {
                "serial_no": str(j - extra_start_row + 1),
                "ref_bsr": str(ws_extra.iloc[j, 1]) if pd.notnull(ws_extra.iloc[j, 1]) else "",
                "description": str(ws_extra.iloc[j, 2]) if pd.notnull(ws_extra.iloc[j, 2]) else "",
                "unit": "",
                "quantity": qty,
                "rate": rate,
                "amount": amount if amount else round(qty * rate) if qty and rate else 0,
                "remark": str(ws_extra.iloc[j, 6]) if j < ws_extra.shape[1] and pd.notnull(ws_extra.iloc[j, 6]) else "",
                "is_divider": False
            }
            first_page_data["items"].append(item)
            extra_items_data["items"].append(item.copy())
            extra_items_data["totals"]["payable"] += item["amount"]

    # Calculate totals
    data_items = [item for item in first_page_data["items"] if not item.get("is_divider", False)]
    total_amount = round(sum(item.get("amount", 0) for item in data_items))
    premium_amount = round(total_amount * (premium_percent / 100) if premium_type == "above" else -total_amount * (premium_percent / 100))
    original_payable = round(total_amount + premium_amount)
    payable_amount = round(original_payable - (amount_paid_last_bill if not is_first_bill else 0))

    first_page_data["totals"] = {
        "grand_total": total_amount,
        "premium": {"percent": premium_percent / 100, "type": premium_type, "amount": premium_amount},
        "original_payable": original_payable,
        "payable": payable_amount,
        "amount_paid_last_bill": amount_paid_last_bill if not is_first_bill else 0,
        "extra_items_sum": extra_items_data["totals"]["payable"],
        "extra_items_total": extra_items_data["totals"]["payable"]
    }
    note_sheet_data["totals"] = first_page_data["totals"].copy()

    # Certificate II and III
    certificate_ii_data = {
        "payable_amount": payable_amount,
        "amount_words": number_to_words(payable_amount),
        "summary": first_page_data["totals"].copy()
    }
    certificate_iii_data = {
        "payable_amount": payable_amount,
        "amount_words": number_to_words(payable_amount),
        "summary": first_page_data["totals"].copy(),
        "certification": "Certified that the work has been completed as per specifications."
    }

    # Deviation Statement (only for final bill)
    if is_final_bill:
        last_row_wo = ws_wo.shape[0]
        work_order_total = 0
        executed_total = 0
        overall_excess = 0
        overall_saving = 0
        
        for i in range(data_start_row, last_row_wo):
            # Skip empty rows
            if pd.isna(ws_wo.iloc[i, 0]) and pd.isna(ws_wo.iloc[i, 1]) and pd.isna(ws_wo.iloc[i, 2]):
                continue
                
            qty_wo_raw = ws_wo.iloc[i, 2] if pd.notnull(ws_wo.iloc[i, 2]) else None
            rate_raw = ws_wo.iloc[i, 3] if pd.notnull(ws_wo.iloc[i, 3]) else None
            qty_bill_raw = ws_bq.iloc[i, 2] if i < ws_bq.shape[0] and pd.notnull(ws_bq.iloc[i, 2]) else None

            qty_wo = 0
            if isinstance(qty_wo_raw, (int, float)):
                qty_wo = float(qty_wo_raw)
            elif isinstance(qty_wo_raw, str):
                cleaned_qty_wo = qty_wo_raw.strip().replace(',', '').replace(' ', '')
                try:
                    qty_wo = float(cleaned_qty_wo)
                except ValueError:
                    logger.debug(f"Skipping invalid qty_wo at row {i+1}: '{qty_wo_raw}'")
                    continue

            rate = 0
            if isinstance(rate_raw, (int, float)):
                rate = float(rate_raw)
            elif isinstance(rate_raw, str):
                cleaned_rate = rate_raw.strip().replace(',', '').replace(' ', '')
                try:
                    rate = float(cleaned_rate)
                except ValueError:
                    logger.debug(f"Skipping invalid rate at row {i+1}: '{rate_raw}'")
                    continue

            qty_bill = 0
            if isinstance(qty_bill_raw, (int, float)):
                qty_bill = float(qty_bill_raw)
            elif isinstance(qty_bill_raw, str):
                cleaned_qty_bill = qty_bill_raw.strip().replace(',', '').replace(' ', '')
                try:
                    qty_bill = float(cleaned_qty_bill)
                except ValueError:
                    logger.debug(f"Skipping invalid qty_bill at row {i+1}: '{qty_bill_raw}'")
                    continue

            amt_wo = round(qty_wo * rate)
            amt_bill = round(qty_bill * rate)
            excess_qty = qty_bill - qty_wo if qty_bill > qty_wo else 0
            excess_amt = round(excess_qty * rate) if excess_qty > 0 else 0
            saving_qty = qty_wo - qty_bill if qty_bill < qty_wo else 0
            saving_amt = round(saving_qty * rate) if saving_qty > 0 else 0

            item = {
                "serial_no": str(i - data_start_row + 1),
                "description": str(ws_wo.iloc[i, 0]) if pd.notnull(ws_wo.iloc[i, 0]) else "",
                "unit": str(ws_wo.iloc[i, 1]) if pd.notnull(ws_wo.iloc[i, 1]) else "",
                "qty_wo": qty_wo,
                "rate": rate,
                "amt_wo": amt_wo,
                "qty_bill": qty_bill,
                "amt_bill": amt_bill,
                "excess_qty": excess_qty,
                "excess_amt": excess_amt,
                "saving_qty": saving_qty,
                "saving_amt": saving_amt,
                "bsr": str(ws_wo.iloc[i, 5]) if i < ws_wo.shape[1] and pd.notnull(ws_wo.iloc[i, 5]) else ""
            }
            deviation_data["items"].append(item)
            work_order_total += amt_wo
            executed_total += amt_bill
            overall_excess += excess_amt
            overall_saving += saving_amt

        # Deviation Summary
        tender_premium_f = round(work_order_total * (premium_percent / 100) if premium_type == "above" else -work_order_total * (premium_percent / 100))
        tender_premium_h = round(executed_total * (premium_percent / 100) if premium_type == "above" else -executed_total * (premium_percent / 100))
        tender_premium_j = round(overall_excess * (premium_percent / 100) if premium_type == "above" else -overall_excess * (premium_percent / 100))
        tender_premium_l = round(overall_saving * (premium_percent / 100) if premium_type == "above" else -overall_saving * (premium_percent / 100))
        grand_total_f = work_order_total + tender_premium_f
        grand_total_h = executed_total + tender_premium_h
        grand_total_j = overall_excess + tender_premium_j
        grand_total_l = overall_saving + tender_premium_l
        net_difference = grand_total_h - grand_total_f

        deviation_data["summary"] = {
            "work_order_total": round(work_order_total),
            "executed_total": round(executed_total),
            "overall_excess": round(overall_excess),
            "overall_saving": round(overall_saving),
            "premium": {"percent": premium_percent / 100, "type": premium_type},
            "tender_premium_f": tender_premium_f,
            "tender_premium_h": tender_premium_h,
            "tender_premium_j": tender_premium_j,
            "tender_premium_l": tender_premium_l,
            "grand_total_f": grand_total_f,
            "grand_total_h": grand_total_h,
            "grand_total_j": grand_total_j,
            "grand_total_l": grand_total_l,
            "net_difference": round(net_difference)
        }

    # Generate notes for note sheet
    note_sheet_data["notes"] = generate_bill_notes(payable_amount, first_page_data["header"]["work_order_amount"], 
                                                  extra_items_data["totals"]["payable"], note_sheet_data)
    
    logger.debug(f"Completed process_bill with {len(first_page_data['items'])} items")
    return first_page_data, certificate_ii_data, certificate_iii_data, deviation_data, extra_items_data, note_sheet_data

def generate_bill_notes(payable_amount, work_order_amount, extra_item_amount, note_sheet_data):
    """Generate notes for the note sheet based on bill data"""
    percentage_work_done = float(payable_amount / work_order_amount * 100) if work_order_amount > 0 else 0
    notes = []
    serial_number = 1
    
    notes.append(f"{serial_number}. The work has been completed {percentage_work_done:.2f}% of the Work Order Amount.")
    serial_number += 1
    
    if percentage_work_done < 90:
        notes.append(f"{serial_number}. The execution of work at final stage is less than 90% of the Work Order Amount, the Requisite Deviation Statement is enclosed to observe check on unuseful expenditure. Approval of the Deviation is having jurisdiction under this office.")
        serial_number += 1
    elif percentage_work_done > 110:
        notes.append(f"{serial_number}. The execution of work exceeds the Work Order Amount by {percentage_work_done - 100:.2f}%, the Requisite Deviation Statement is enclosed for justification and approval of the Deviation.")
        serial_number += 1
    
    if extra_item_amount > 0:
        extra_percent = float(extra_item_amount / work_order_amount * 100) if work_order_amount > 0 else 0
        notes.append(f"{serial_number}. Extra items worth Rs. {extra_item_amount:.2f} ({extra_percent:.2f}% of Work Order) are claimed in this bill as per requirement and specifications.")
        serial_number += 1
    
    return notes