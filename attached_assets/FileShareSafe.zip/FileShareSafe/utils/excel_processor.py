import pandas as pd
import numpy as np
import logging
import traceback
from datetime import datetime
from typing import Dict, Any, List, Union

logger = logging.getLogger(__name__)

def process_excel_file(filepath: str, last_paid_amount: float, is_final_bill: bool) -> Dict[str, Any]:
    """
    Process the uploaded Excel file and generate bill data
    
    Args:
        filepath: Path to the uploaded Excel file
        last_paid_amount: The amount from the last bill that was paid
        is_final_bill: Boolean flag indicating if this is a final bill
    
    Returns:
        Dictionary containing processed bill data
    """
    try:
        logger.debug(f"Processing file: {filepath}")
        logger.debug(f"Last paid amount: {last_paid_amount}")
        logger.debug(f"Is final bill: {is_final_bill}")
        
        # Read the Excel file
        df = pd.read_excel(filepath)
        
        # Normalize column names to lowercase and trim whitespace
        df.columns = [col.lower().strip() for col in df.columns]
        
        # Replace any NaN values with appropriately typed defaults
        df = df.fillna({
            'item': 'Unnamed Item',
            'rate': 1.0,
            'previous': 0.0,
            'current': 0.0,
            'expected': 0.0
        })
        
        # Basic validation of the input file - find an appropriate item/name column
        if 'item' not in df.columns:
            # First look for common item column names
            item_column_variants = ['item', 'name', 'description', 'service', 'product', 'particulars', 'detail']
            found_item_col = False
            
            # Try exact match first
            for variant in item_column_variants:
                if variant in df.columns:
                    df.rename(columns={variant: 'item'}, inplace=True)
                    found_item_col = True
                    logger.info(f"Using exact match '{variant}' as the 'item' column")
                    break
            
            # If no exact match, try partial match
            if not found_item_col:
                # Look for similar column names
                potential_item_columns = [col for col in df.columns 
                                         if any(term in col for term in item_column_variants)]
                if potential_item_columns:
                    # Use the first potential item column
                    df.rename(columns={potential_item_columns[0]: 'item'}, inplace=True)
                    found_item_col = True
                    logger.info(f"Using '{potential_item_columns[0]}' as the 'item' column")
                else:
                    # Try to find unnamed columns which often contain item data
                    unnamed_cols = [col for col in df.columns if 'unnamed' in str(col).lower()]
                    if unnamed_cols:
                        # Use the first unnamed column as item
                        df.rename(columns={unnamed_cols[0]: 'item'}, inplace=True)
                        found_item_col = True
                        logger.info(f"Using unnamed column '{unnamed_cols[0]}' as the 'item' column")
                    else:
                        # Last resort - use the first column (index 0) as item if it's not numeric
                        first_col = df.columns[0]
                        if first_col not in df.select_dtypes(include=['number']).columns:
                            df.rename(columns={first_col: 'item'}, inplace=True)
                            found_item_col = True
                            logger.info(f"Using first column '{first_col}' as the 'item' column")
                        else:
                            # Create a synthetic item column using row numbers
                            df['item'] = [f"Item {i+1}" for i in range(len(df))]
                            found_item_col = True
                            logger.warning("No suitable item column found. Creating synthetic item names.")
        
        # Log columns for debugging
        logger.debug(f"Available columns in Excel file: {list(df.columns)}")
        
        # Get all numeric columns
        numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
        logger.debug(f"Numeric columns in Excel file: {numeric_cols}")
        
        # Check if we have at least 'current' or 'current reading' column
        has_current = False
        current_column_variants = ['current', 'current reading', 'current value', 'curr', 'current read', 'reading']
        
        for variant in current_column_variants:
            if variant in df.columns:
                if variant != 'current':
                    # Rename to standardize
                    df.rename(columns={variant: 'current'}, inplace=True)
                has_current = True
                logger.info(f"Found standard current column: '{variant}'")
                break
        
        # If exact match not found, try partial match        
        if not has_current:
            # Look for columns with 'current' in the name
            potential_current_cols = [col for col in df.columns if any(term in col for term in ['current', 'curr', 'present', 'reading', 'consumption'])]
            if potential_current_cols:
                df.rename(columns={potential_current_cols[0]: 'current'}, inplace=True)
                has_current = True
                logger.info(f"Using '{potential_current_cols[0]}' as the 'current' column")
            else:
                # If we still can't find a current column, use a numeric column as a last resort
                if numeric_cols:
                    # Try to exclude likely 'rate' columns
                    rate_cols = [col for col in numeric_cols if any(term in col for term in ['rate', 'price', 'cost', 'charge'])]
                    # Use non-rate numeric columns first if available
                    preferred_cols = [col for col in numeric_cols if col not in rate_cols]
                    
                    if preferred_cols:
                        selected_col = preferred_cols[0]
                    else:
                        selected_col = numeric_cols[0]
                    
                    df.rename(columns={selected_col: 'current'}, inplace=True)
                    has_current = True
                    logger.info(f"Using numeric column '{selected_col}' as the 'current' column")
                else:
                    # Last resort - create a dummy column with sample data
                    logger.warning("No suitable numeric column found for current readings. Creating a sample column for testing.")
                    df['current'] = 100  # Sample value
                    has_current = True
        
        # Check if we have 'previous' or 'previous reading' column
        has_previous = False
        previous_column_variants = ['previous', 'previous reading', 'prev', 'previous value', 'previous read', 'old', 'last']
        
        for variant in previous_column_variants:
            if variant in df.columns:
                if variant != 'previous':
                    # Rename to standardize
                    df.rename(columns={variant: 'previous'}, inplace=True)
                has_previous = True
                logger.info(f"Found standard previous column: '{variant}'")
                break
        
        # If no previous column exists, create one with all zeros
        if not has_previous:
            # Look for columns with 'previous' in the name
            potential_previous_cols = [col for col in df.columns if any(term in col for term in ['previous', 'prev', 'last', 'old', 'initial', 'opening'])]
            if potential_previous_cols:
                df.rename(columns={potential_previous_cols[0]: 'previous'}, inplace=True)
                has_previous = True
                logger.info(f"Using '{potential_previous_cols[0]}' as the 'previous' column")
            else:
                # Look for a second numeric column that might be previous reading
                numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
                if len(numeric_cols) > 1 and 'current' in df.columns:
                    # Find a numeric column that's not 'current' and not likely a rate
                    potential_prev_numeric = [col for col in numeric_cols if col != 'current' and not any(term in col for term in ['rate', 'price', 'cost'])]
                    if potential_prev_numeric:
                        df.rename(columns={potential_prev_numeric[0]: 'previous'}, inplace=True)
                        has_previous = True
                        logger.info(f"Using numeric column '{potential_prev_numeric[0]}' as the 'previous' column")
                    else:
                        df['previous'] = 0
                        logger.info("No suitable previous column found. Using zeros for previous readings.")
                else:
                    df['previous'] = 0
                    logger.info("No 'previous' column found. Using zeros for previous readings.")
        
        # Check if we have 'rate' column, if not, default to 1
        if 'rate' not in df.columns:
            rate_column_variants = ['rate', 'price', 'unit price', 'unit rate', 'cost', 'charge', 'fee', 'tariff']
            found_rate = False
            
            # Try exact match first
            for variant in rate_column_variants:
                if variant in df.columns:
                    df.rename(columns={variant: 'rate'}, inplace=True)
                    found_rate = True
                    logger.info(f"Using exact match '{variant}' as the 'rate' column")
                    break
            
            # Try partial match if exact match failed
            if not found_rate:
                potential_rate_cols = [col for col in df.columns if any(term in col for term in rate_column_variants)]
                if potential_rate_cols:
                    df.rename(columns={potential_rate_cols[0]: 'rate'}, inplace=True)
                    found_rate = True
                    logger.info(f"Using '{potential_rate_cols[0]}' as the 'rate' column")
                else:
                    # Look for numeric columns that might be rates
                    numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
                    # Exclude columns already identified as 'current' or 'previous'
                    other_numeric_cols = [col for col in numeric_cols if col not in ['current', 'previous']]
                    
                    if other_numeric_cols:
                        # Use the first remaining numeric column as rate
                        df.rename(columns={other_numeric_cols[0]: 'rate'}, inplace=True)
                        found_rate = True
                        logger.info(f"Using numeric column '{other_numeric_cols[0]}' as the 'rate' column")
                    else:
                        # Default to 1 if no suitable rate column found
                        df['rate'] = 1
                        logger.info("No suitable rate column found. Using default rate of 1.")
            
            # Further optimization: if rates are all 0, set to 1
            if 'rate' in df.columns and (df['rate'] == 0).all():
                logger.warning("Rate column contains all zeros. Setting default rate to 1.")
                df['rate'] = 1
        
        # Convert data types to ensure numeric calculations
        numeric_columns = ['current', 'previous', 'rate']
        for col in numeric_columns:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)
        
        # Calculate consumption (current - previous)
        df['consumption'] = df['current'] - df['previous']
        
        # Calculate amount (consumption * rate)
        df['amount'] = df['consumption'] * df['rate']
        
        # Calculate the total bill amount
        total_bill_amount = df['amount'].sum()
        
        # Calculate adjustment amount (difference between last paid and current total)
        adjustment = 0
        if last_paid_amount > 0:
            adjustment = last_paid_amount - total_bill_amount
        
        # Generate bill details
        bill_items = []
        for _, row in df.iterrows():
            item_data = {
                'item': str(row['item']),  # Ensure item is a string
                'previous': float(row['previous']),
                'current': float(row['current']),
                'consumption': float(row['consumption']),
                'rate': float(row['rate']),
                'amount': float(row['amount'])
            }
            bill_items.append(item_data)
        
        # Generate deviations if it's a final bill
        deviations = []
        if is_final_bill:
            # Check for expected column or similar
            expected_column_variants = ['expected', 'expected value', 'plan', 'target', 'budget']
            has_expected = False
            
            for variant in expected_column_variants:
                if variant in df.columns:
                    if variant != 'expected':
                        df.rename(columns={variant: 'expected'}, inplace=True)
                    has_expected = True
                    break
            
            if not has_expected:
                # Try to find other columns that might represent expected values
                potential_expected_cols = [col for col in df.columns if 'expect' in col or 'plan' in col or 'target' in col or 'budget' in col]
                if potential_expected_cols:
                    df.rename(columns={potential_expected_cols[0]: 'expected'}, inplace=True)
                    has_expected = True
                    logger.info(f"Using '{potential_expected_cols[0]}' as the 'expected' column for deviations")
                else:
                    # If no expected column, we'll just compare with previous if available
                    logger.info("No 'expected' column found for deviations. Using previous values if available, or calculating estimates.")
                    if 'previous' in df.columns and df['previous'].sum() > 0:
                        df['expected'] = df['previous'] 
                    else:
                        # If no good reference, we'll use the current values as a baseline (not ideal but better than nothing)
                        df['expected'] = df['current'] * 0.9  # Assuming a 10% difference is notable
            
            # Convert expected to numeric to ensure proper calculations
            df['expected'] = pd.to_numeric(df['expected'], errors='coerce').fillna(0)
            
            # Calculate deviations for all items
            for _, row in df.iterrows():
                expected = float(row['expected'])
                actual = float(row['consumption'])
                deviation = actual - expected
                percentage = (deviation / expected * 100) if expected != 0 else 0
                
                # Only include significant deviations
                if abs(deviation) > 0.01 and (abs(percentage) > 1 or abs(deviation) > 1):  # Filter out tiny deviations
                    deviations.append({
                        'item': str(row['item']),
                        'expected': expected,
                        'actual': actual,
                        'deviation': deviation,
                        'percentage': percentage
                    })
        
        # Prepare the bill data for display
        bill_data = {
            'bill_date': datetime.now().strftime('%Y-%m-%d'),
            'bill_items': bill_items,  # Changed from 'items' to avoid Python built-in conflict
            'total_amount': float(total_bill_amount),
            'last_paid_amount': float(last_paid_amount),
            'adjustment': float(adjustment),
            'final_amount': float(total_bill_amount - adjustment),
            'is_final_bill': is_final_bill,
            'deviations': deviations
        }
        
        logger.debug(f"Bill data generated successfully with {len(bill_items)} items and {len(deviations)} deviations")
        return bill_data
        
    except Exception as e:
        logger.error(f"Error processing Excel file: {str(e)}")
        logger.error(traceback.format_exc())
        raise ValueError(f"Error processing Excel file: {str(e)}")
