// Bill Generator Frontend JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Get form elements
    const uploadForm = document.getElementById('uploadForm');
    const excelFileInput = document.getElementById('excel_file');
    const validateButton = document.getElementById('validateButton');
    const generateButton = document.getElementById('generateButton');
    const feedbackDiv = document.getElementById('fileValidationFeedback');
    
    // Add event listeners
    if (validateButton) {
        validateButton.addEventListener('click', validateExcelFile);
    }
    
    if (excelFileInput) {
        excelFileInput.addEventListener('change', function() {
            // Clear previous validation feedback when a new file is selected
            feedbackDiv.innerHTML = '';
            feedbackDiv.className = '';
        });
    }
    
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(event) {
            if (!excelFileInput.files.length) {
                event.preventDefault();
                showFeedback('Please select an Excel file to upload.', 'error');
                return false;
            }
            
            // Show loading state
            generateButton.disabled = true;
            generateButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Generating...';
            return true;
        });
    }
    
    /**
     * Validates the Excel file using an AJAX request
     */
    function validateExcelFile() {
        if (!excelFileInput.files.length) {
            showFeedback('Please select a file first.', 'error');
            return;
        }
        
        const file = excelFileInput.files[0];
        const formData = new FormData();
        formData.append('excel_file', file);
        
        // Show loading state
        validateButton.disabled = true;
        validateButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Validating...';
        
        // Send AJAX request to validate the file
        fetch('/check_file', {
            method: 'POST',
            body: formData,
            headers: {
                'Accept': 'application/json'
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.valid) {
                showFeedback(data.message, 'success');
            } else {
                showFeedback(data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showFeedback('An error occurred while validating the file.', 'error');
        })
        .finally(() => {
            // Reset button state
            validateButton.disabled = false;
            validateButton.innerHTML = '<i class="fas fa-check-circle"></i> Validate';
        });
    }
    
    /**
     * Shows feedback message to the user
     * @param {string} message - The message to display
     * @param {string} type - The type of feedback (success/error)
     */
    function showFeedback(message, type) {
        feedbackDiv.innerHTML = '';
        
        const icon = document.createElement('i');
        icon.className = type === 'success' ? 'fas fa-check-circle me-2' : 'fas fa-exclamation-circle me-2';
        
        const messageSpan = document.createElement('span');
        messageSpan.textContent = message;
        
        const alert = document.createElement('div');
        alert.className = type === 'success' ? 'alert alert-success' : 'alert alert-danger';
        alert.appendChild(icon);
        alert.appendChild(messageSpan);
        
        feedbackDiv.appendChild(alert);
    }
});
