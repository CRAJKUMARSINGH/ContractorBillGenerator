# This file is intentionally minimal to avoid route conflicts
# All routes and app configuration are in main.py
from main import app
