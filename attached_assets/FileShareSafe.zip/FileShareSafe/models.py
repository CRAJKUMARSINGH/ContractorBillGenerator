from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
import json

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

class Bill(db.Model):
    """Model for storing bill information"""
    id = db.Column(db.Integer, primary_key=True)
    bill_date = db.Column(db.DateTime, default=datetime.utcnow)
    last_paid_amount = db.Column(db.Float, default=0.0)
    total_amount = db.Column(db.Float, nullable=False)
    adjustment = db.Column(db.Float, default=0.0)
    final_amount = db.Column(db.Float, nullable=False)
    is_final_bill = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    bill_items = db.relationship('BillItem', backref='bill', lazy=True, cascade="all, delete-orphan")
    deviations = db.relationship('BillDeviation', backref='bill', lazy=True, cascade="all, delete-orphan")
    
    def __repr__(self):
        return f'<Bill {self.id}: ${self.final_amount} on {self.bill_date}>'
    
    def to_dict(self):
        """Convert bill to dictionary for use in templates"""
        return {
            'id': self.id,
            'bill_date': self.bill_date.strftime('%Y-%m-%d'),
            'last_paid_amount': self.last_paid_amount,
            'total_amount': self.total_amount,
            'adjustment': self.adjustment,
            'final_amount': self.final_amount,
            'is_final_bill': self.is_final_bill,
            'bill_items': [item.to_dict() for item in self.bill_items],
            'deviations': [dev.to_dict() for dev in self.deviations],
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }
    
    @classmethod
    def from_bill_data(cls, bill_data):
        """Create a bill from processed bill data dictionary"""
        bill = cls(
            bill_date=datetime.now(),
            last_paid_amount=bill_data['last_paid_amount'],
            total_amount=bill_data['total_amount'],
            adjustment=bill_data['adjustment'],
            final_amount=bill_data['final_amount'],
            is_final_bill=bill_data['is_final_bill']
        )
        
        # Add bill items
        for item_data in bill_data['bill_items']:
            bill_item = BillItem(
                item_name=item_data['item'],
                previous_reading=item_data['previous'],
                current_reading=item_data['current'],
                consumption=item_data['consumption'],
                rate=item_data['rate'],
                amount=item_data['amount'],
                bill=bill
            )
            bill.bill_items.append(bill_item)
        
        # Add deviations for final bills
        if bill.is_final_bill and 'deviations' in bill_data and bill_data['deviations']:
            for dev_data in bill_data['deviations']:
                deviation = BillDeviation(
                    item_name=dev_data['item'],
                    expected_value=dev_data['expected'],
                    actual_value=dev_data['actual'],
                    deviation=dev_data['deviation'],
                    percentage=dev_data['percentage'],
                    bill=bill
                )
                bill.deviations.append(deviation)
        
        return bill


class BillItem(db.Model):
    """Model for storing individual bill items"""
    id = db.Column(db.Integer, primary_key=True)
    bill_id = db.Column(db.Integer, db.ForeignKey('bill.id'), nullable=False)
    item_name = db.Column(db.String(255), nullable=False)
    previous_reading = db.Column(db.Float, default=0.0)
    current_reading = db.Column(db.Float, nullable=False)
    consumption = db.Column(db.Float, nullable=False)
    rate = db.Column(db.Float, default=1.0)
    amount = db.Column(db.Float, nullable=False)
    
    def __repr__(self):
        return f'<BillItem {self.id}: {self.item_name} - ${self.amount}>'
    
    def to_dict(self):
        """Convert bill item to dictionary for use in templates"""
        return {
            'id': self.id,
            'item': self.item_name,
            'previous': self.previous_reading,
            'current': self.current_reading,
            'consumption': self.consumption,
            'rate': self.rate,
            'amount': self.amount
        }


class BillDeviation(db.Model):
    """Model for storing deviations in final bills"""
    id = db.Column(db.Integer, primary_key=True)
    bill_id = db.Column(db.Integer, db.ForeignKey('bill.id'), nullable=False)
    item_name = db.Column(db.String(255), nullable=False)
    expected_value = db.Column(db.Float, nullable=False)
    actual_value = db.Column(db.Float, nullable=False)
    deviation = db.Column(db.Float, nullable=False)
    percentage = db.Column(db.Float, nullable=False)
    
    def __repr__(self):
        return f'<BillDeviation {self.id}: {self.item_name} - {self.deviation}>'
    
    def to_dict(self):
        """Convert deviation to dictionary for use in templates"""
        return {
            'id': self.id,
            'item': self.item_name,
            'expected': self.expected_value,
            'actual': self.actual_value,
            'deviation': self.deviation,
            'percentage': self.percentage
        }